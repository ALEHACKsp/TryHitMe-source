Osiris with a rage and stuff
credits to
[notgoodusename (me)](https://github.com/notgoodusename)
[Xoom](https://github.com/Xoom7573)