#include <functional>
#include <intrin.h>
#include <string>
#include <Windows.h>
#include <Psapi.h>

#include "imgui/imgui.h"
#include "imgui/imgui_impl_dx9.h"
#include "imgui/imgui_impl_win32.h"

#include "MinHook/MinHook.h"

#include "Config.h"
#include "EventListener.h"
#include "ExtraHooks.h"
#include "GUI.h"
#include "Hooks.h"
#include "Interfaces.h"
#include "Memory.h"

#include "Hacks/Aimbot.h"
#include "Hacks/Animations.h"
#include "Hacks/AntiAim.h"
#include "Hacks/Backtrack.h"
#include "Hacks/Chams.h"
#include "Hacks/EnginePrediction.h"
#include "Hacks/Esp.h"
#include "Hacks/GrenadePrediction.h"
#include "Hacks/Glow.h"
#include "Hacks/Misc.h"
#include "Hacks/Legitbot.h"
#include "Hacks/Ragebot.h"
#include "Hacks/SkinChanger.h"
#include "Hacks/Tickbase.h"
#include "Hacks/Triggerbot.h"
#include "Hacks/Visuals.h"

#include "SDK/Engine.h"
#include "SDK/Entity.h"
#include "SDK/EntityList.h"
#include "SDK/FrameStage.h"
#include "SDK/GameEvent.h"
#include "SDK/GameMovement.h"
#include "SDK/GameUI.h"
#include "SDK/Input.h"
#include "SDK/InputSystem.h"
#include "SDK/MaterialSystem.h"
#include "SDK/ModelRender.h"
#include "SDK/Panel.h"
#include "SDK/Prediction.h"
#include "SDK/RenderContext.h"
#include "SDK/SoundInfo.h"
#include "SDK/SoundEmitter.h"
#include "SDK/StudioRender.h"
#include "SDK/Surface.h"
#include "SDK/UserCmd.h"

static LRESULT __stdcall wndProc(HWND window, UINT msg, WPARAM wParam, LPARAM lParam) noexcept
{
    static const auto once = [](HWND window) noexcept {
        netvars = std::make_unique<Netvars>();
        eventListener = std::make_unique<EventListener>();
        config = std::make_unique<Config>("Osiris");
        Tickbase::tick = std::make_unique<Tickbase::Tick>();

        ImGui::CreateContext();
        ImGui_ImplWin32_Init(window);
        gui = std::make_unique<GUI>();

        hooks->install();

        return true;
    }(window);

    if (msg == WM_KEYDOWN && LOWORD(wParam) == config->misc.menuKey
        || ((msg == WM_LBUTTONDOWN || msg == WM_LBUTTONDBLCLK) && config->misc.menuKey == VK_LBUTTON)
        || ((msg == WM_RBUTTONDOWN || msg == WM_RBUTTONDBLCLK) && config->misc.menuKey == VK_RBUTTON)
        || ((msg == WM_MBUTTONDOWN || msg == WM_MBUTTONDBLCLK) && config->misc.menuKey == VK_MBUTTON)
        || ((msg == WM_XBUTTONDOWN || msg == WM_XBUTTONDBLCLK) && config->misc.menuKey == HIWORD(wParam) + 4)) {
        gui->open = !gui->open;
        if (!gui->open) {
            // ImGui::GetIO().MouseDown[0] = false;
            interfaces->inputSystem->resetInputState();
        }
    }

    LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
    ImGui_ImplWin32_WndProcHandler(window, msg, wParam, lParam);

    interfaces->inputSystem->enableInput(!gui->open);

    return CallWindowProcW(hooks->originalWndProc, window, msg, wParam, lParam);
}

static HRESULT __stdcall present(IDirect3DDevice9* device, const RECT* src, const RECT* dest, HWND windowOverride, const RGNDATA* dirtyRegion) noexcept
{
    static bool imguiInit{ ImGui_ImplDX9_Init(device) };

    ImGui_ImplDX9_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    nadePrediction::draw();
    Misc::purchaseList();
    Misc::spectatorList();

    Misc::debugwindow();
    
    Misc::watermark();

    if (gui->open)
        gui->render();

    ImGui::EndFrame();
    ImGui::Render();

    if (device->BeginScene() == D3D_OK) {
        ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
        device->EndScene();
    }

    return hooks->originalPresent(device, src, dest, windowOverride, dirtyRegion);
}

static HRESULT __stdcall reset(IDirect3DDevice9* device, D3DPRESENT_PARAMETERS* params) noexcept
{
    ImGui_ImplDX9_InvalidateDeviceObjects();
    return hooks->originalReset(device, params);
}

static bool __fastcall sendNetMsg(void* networkchannel, void* edx, NetworkMessage& msg, bool bForceReliable, bool bVoice)
{
    auto original = hooks->networkChannel.getOriginal<bool, NetworkMessage&, bool, bool>(40, msg, bForceReliable, bVoice);

    if (msg.getType() == 14 && config->misc.svpurebypass) // Return and don't send messsage if its FileCRCCheck
        return false;

    return original(networkchannel, msg, bForceReliable, bVoice);
}

static int __fastcall sendDatagram(NetworkChannel* network, void* edx, void* datagram)
{
    auto original = hooks->networkChannel.getOriginal<int, void*>(46, datagram);
    if (!config->backtrack.fakeLatency || datagram || !interfaces->engine->isInGame())
    {
        return original(network, datagram);
    }
    int instate = network->InReliableState;
    int insequencenr = network->InSequenceNr;

    float delta = max(0.f, std::clamp(config->backtrack.fakeLatencyAmount / 1000.f, 0.f, Backtrack::cvars.maxUnlag->getFloat()) - network->getLatency(0));

    Backtrack::AddLatencyToNetwork(network, delta);

    int result = original(network, datagram);

    network->InReliableState = instate;
    network->InSequenceNr = insequencenr;

    return result;
}

static bool __stdcall createMove(float inputSampleTime, UserCmd* cmd) noexcept
{
    auto result = hooks->clientMode.callOriginal<bool, 24>(inputSampleTime, cmd);

    if (!cmd->commandNumber)
        return result;

    uintptr_t* framePointer;
    __asm mov framePointer, ebp;
    bool& sendPacket = *reinterpret_cast<bool*>(*framePointer - 0x1C);

    static auto previousViewAngles{ cmd->viewangles };
    const auto oldCurrentViewAngles{ cmd->viewangles };

    float angle = Misc::autoStrafe(cmd, oldCurrentViewAngles);
    const auto currentViewAngles{ cmd->viewangles };
    memory->globalVars->serverTime(cmd);
    Misc::nadeTrajectory();
    Misc::showImpacts();
    Misc::antiAfkKick(cmd);
    Misc::fastPlant(cmd);
    Misc::prepareRevolver(cmd);
    Misc::sniperCrosshair();
    Misc::recoilCrosshair();
    Visuals::removeShadows();
    Misc::bunnyHop(cmd);
    Misc::removeCrouchCooldown(cmd);
    Misc::autoPistol(cmd);
    Misc::clanTag();
    Misc::fakeBan();
    Misc::stealNames();
    Misc::revealRanks(cmd);
    Misc::fastStop(cmd);
    Misc::slowwalk(cmd);
    Ragebot::autoStop(cmd);

    extraHook.init();

    static void* oldPointer = nullptr;

    auto network = interfaces->engine->getNetworkChannel();
    if (oldPointer != network && network && interfaces->engine->isInGame())
    {
        oldPointer = network;
        hooks->networkChannel.init(network);
        hooks->networkChannel.hookAt(40, sendNetMsg);
        hooks->networkChannel.hookAt(46, sendDatagram);
    }
    Backtrack::UpdateIncomingSequences();

    EnginePrediction::run(cmd);
    nadePrediction::run(cmd);
    cmd->viewangles.y -= angle; //ghetto fix

    Legitbot::run(cmd);
    Backtrack::run(cmd);
    Triggerbot::run(cmd);
    Ragebot::run(cmd);
    Tickbase::run(cmd);

    Resolver::UpdateShots(cmd);

    Misc::edgejump(cmd);
    Misc::moonwalk(cmd);

    Misc::quickPeek(cmd);

    AntiAim::fakeLag(cmd, sendPacket);
    AntiAim::fakeDuck(cmd);
    cmd->viewangles.y += angle;
    AntiAim::run(cmd, previousViewAngles, currentViewAngles, sendPacket);
    cmd->viewangles.y -= angle;

    auto viewAnglesDelta{ cmd->viewangles - previousViewAngles };
    viewAnglesDelta.normalize();
    viewAnglesDelta.x = std::clamp(viewAnglesDelta.x, -config->misc.maxAngleDelta, config->misc.maxAngleDelta);
    viewAnglesDelta.y = std::clamp(viewAnglesDelta.y, -config->misc.maxAngleDelta, config->misc.maxAngleDelta);

    cmd->viewangles = previousViewAngles + viewAnglesDelta;

    cmd->viewangles.normalize();
    Misc::fixMovement(cmd, currentViewAngles.y);

    cmd->viewangles.x = std::clamp(cmd->viewangles.x, -89.0f, 89.0f);
    cmd->viewangles.y = std::clamp(cmd->viewangles.y, -180.0f, 180.0f);
    cmd->viewangles.z = 0.0f;
    cmd->forwardmove = std::clamp(cmd->forwardmove, -450.0f, 450.0f);
    cmd->sidemove = std::clamp(cmd->sidemove, -450.0f, 450.0f);

    previousViewAngles = cmd->viewangles;
    Animations::update(cmd,sendPacket);
    Animations::fake();
    return false;
}

static int __stdcall doPostScreenEffects(int param) noexcept
{
    if (interfaces->engine->isInGame()) {
        Visuals::thirdperson();
        Misc::inverseRagdollGravity();
        Visuals::reduceFlashEffect();
        Visuals::updateBrightness();
        Visuals::remove3dSky();
        Visuals::nightMode();
        Glow::render();
    }
    return hooks->clientMode.callOriginal<int, 44>(param);
}

static float __stdcall getViewModelFov() noexcept
{
    float additionalFov = static_cast<float>(config->visuals.viewmodelFov);
    if (localPlayer) {
        if (const auto activeWeapon = localPlayer->getActiveWeapon(); activeWeapon && activeWeapon->getClientClass()->classId == ClassId::Tablet)
            additionalFov = 0.0f;
    }

    return hooks->clientMode.callOriginal<float, 35>() + additionalFov;
}

static void __stdcall drawModelExecute(void* ctx, void* state, const ModelRenderInfo& info, matrix3x4* customBoneToWorld) noexcept
{
    if (interfaces->studioRender->isForcedMaterialOverride())
        return hooks->modelRender.callOriginal<void, 21>(ctx, state, std::cref(info), customBoneToWorld);

    if (Visuals::removeHands(info.model->name) || Visuals::removeSleeves(info.model->name) || Visuals::removeWeapons(info.model->name))
        return;

    static Chams chams;
    if (!chams.render(ctx, state, info, customBoneToWorld))
        hooks->modelRender.callOriginal<void, 21>(ctx, state, std::cref(info), customBoneToWorld);
    interfaces->studioRender->forcedMaterialOverride(nullptr);
}

static bool __fastcall svCheatsGetBool(void* _this) noexcept
{
    if (uintptr_t(_ReturnAddress()) == memory->cameraThink && config->visuals.thirdperson)
        return true;
    else
        return hooks->svCheats.getOriginal<bool>(13)(_this);
}

static void __stdcall paintTraverse(unsigned int panel, bool forceRepaint, bool allowForce) noexcept
{
    static bool alreadyCalled = false;
    if (!alreadyCalled)
    {
        hooks->tahomaBoldAA = interfaces->surface->createFont(); interfaces->surface->setFontGlyphSet(hooks->tahomaBoldAA, "Tahoma", 12, 500, 0, 0, 0x010 | 0x080, 0, 0);
        hooks->smallFonts = interfaces->surface->createFont(); interfaces->surface->setFontGlyphSet(hooks->smallFonts, "Small Fonts", 9, 500, 0, 0, 0x200, 0, 0);
        hooks->tahomaAA = interfaces->surface->createFont(); interfaces->surface->setFontGlyphSet(hooks->tahomaAA, "Tahoma", 12, 400, 0, 0, 0x010 | 0x080, 0, 0);
        hooks->tahomaNoShadowAA = interfaces->surface->createFont(); interfaces->surface->setFontGlyphSet(hooks->tahomaNoShadowAA, "Tahoma", 12, 400, 0, 0, 0x010, 0, 0);
        hooks->verdanaExtraBoldAA = interfaces->surface->createFont(); interfaces->surface->setFontGlyphSet(hooks->verdanaExtraBoldAA, "Verdana", 25, 800, 0, 0, 0x010 | 0x080, 0, 0);

        alreadyCalled = true;
    }

    if (interfaces->panel->getName(panel) == "MatSystemTopPanel") {
        Esp::render();
        Misc::drawBombTimer();
        Visuals::hitMarker();
        Misc::drawQuickPeekStartPos();
        Visuals::aaLines();
    }
    hooks->panel.callOriginal<void, 41>(panel, forceRepaint, allowForce);
}

static void __stdcall frameStageNotify(FrameStage stage) noexcept
{
    static auto backtrackInit = (Backtrack::init(), false);

    if (interfaces->engine->isConnected() && !interfaces->engine->isInGame())
        Misc::changeName(true, nullptr, 0.0f);

    if (stage == FrameStage::RENDER_START) {
        for (size_t i = 0; i < config->ragebot.size(); i++)
        {
            if (config->ragebot[i].enabled && config->legitbot[i].enabled)
            {
                config->ragebot[i].enabled = false;
            }
        }
        Misc::disablePanoramablur();
        Misc::fakePrime();
        Animations::players();
        Animations::real();
    }
    if (interfaces->engine->isInGame()) {
        Visuals::skybox(stage);

        Misc::oppositeHandKnife(stage);

        Visuals::removeGrass(stage);
        Visuals::modifySmoke(stage);
        Visuals::removeBlur(stage);
        Visuals::playerModel(stage);
        Visuals::disablePostProcessing(stage);
        Visuals::removeVisualRecoil(stage);
        Backtrack::update(stage);
        SkinChanger::run(stage);
    }
    hooks->client.callOriginal<void, 37>(stage);
}

struct SoundData {
    std::byte pad[4];
    int entityIndex;
    int channel;
    const char* soundEntry;
    std::byte pad1[8];
    float volume;
    std::byte pad2[44];
};

static void __stdcall emitSound(SoundData data) noexcept
{
    auto modulateVolume = [&data](int(*get)(int)) {
        if (const auto entity = interfaces->entityList->getEntity(data.entityIndex); localPlayer && entity && entity->isPlayer()) {
            if (data.entityIndex == localPlayer->index())
                data.volume *= get(0) / 100.0f;
            else if (!entity->isOtherEnemy(localPlayer.get()))
                data.volume *= get(1) / 100.0f;
            else
                data.volume *= get(2) / 100.0f;
        }
    };

    modulateVolume([](int index) { return config->sound.players[index].masterVolume; });

    if (strstr(data.soundEntry, "Weapon") && strstr(data.soundEntry, "Single")) {
        modulateVolume([](int index) { return config->sound.players[index].weaponVolume; });
    } else if (config->misc.autoAccept && !strcmp(data.soundEntry, "UIPanorama.popup_accept_match_beep")) {
        memory->acceptMatch("");
        auto window = FindWindowW(L"Valve001", NULL);
        FLASHWINFO flash{ sizeof(FLASHWINFO), window, FLASHW_TRAY | FLASHW_TIMERNOFG, 0, 0 };
        FlashWindowEx(&flash);
        ShowWindow(window, SW_RESTORE);
    }
    data.volume = std::clamp(data.volume, 0.0f, 1.0f);
    hooks->sound.callOriginal<void, 5>(data);
}

static bool __stdcall shouldDrawFog() noexcept
{
    if constexpr (std::is_same_v<HookType, MinHook>) {
#ifdef _DEBUG
    // Check if we always get the same return address
    if (*static_cast<std::uint32_t*>(_ReturnAddress()) == 0x6274C084) {
        static const auto returnAddress = std::uintptr_t(_ReturnAddress());
        assert(returnAddress == std::uintptr_t(_ReturnAddress()));
    }
#endif

    if (*static_cast<std::uint32_t*>(_ReturnAddress()) != 0x6274C084)
        return hooks->clientMode.callOriginal<bool, 17>();
    }

    return !config->visuals.noFog;
}

static bool __stdcall shouldDrawViewModel() noexcept
{
    if (localPlayer && localPlayer->fov() < 45 && localPlayer->fovStart() < 45)
        return false;
    return hooks->clientMode.callOriginal<bool, 27>();
}

static void __stdcall lockCursor() noexcept
{
    if (gui->open)
        return interfaces->surface->unlockCursor();
    return hooks->surface.callOriginal<void, 67>();
}

static void __stdcall setDrawColor(int r, int g, int b, int a) noexcept
{
#ifdef _DEBUG
    // Check if we always get the same return address
    if (*static_cast<std::uint32_t*>(_ReturnAddress()) == 0x20244C8B) {
        static const auto returnAddress = std::uintptr_t(_ReturnAddress());
        assert(returnAddress == std::uintptr_t(_ReturnAddress()));
    }
    if (*reinterpret_cast<std::uint32_t*>(std::uintptr_t(_ReturnAddress()) + 6) == 0x01ACB7FF) {
        static const auto returnAddress = std::uintptr_t(_ReturnAddress());
        assert(returnAddress == std::uintptr_t(_ReturnAddress()));
    }
#endif

    if (config->visuals.noScopeOverlay && (*static_cast<std::uint32_t*>(_ReturnAddress()) == 0x20244C8B || *reinterpret_cast<std::uint32_t*>(std::uintptr_t(_ReturnAddress()) + 6) == 0x01ACB7FF))
        a = 0;
    hooks->surface.callOriginal<void, 15>(r, g, b, a);
}

static bool __stdcall fireEventClientSide(GameEvent* event) noexcept
{
    // TODO: remove this hook after testing the new method of overriding knife icon
    if (event) {
        switch (fnv::hashRuntime(event->getName())) {
        case fnv::hash("player_death"):
            // SkinChanger::overrideHudIcon(*event);
            break;
        }
    }
    return hooks->gameEventManager.callOriginal<bool, 9>(event);
}

struct ViewSetup {
    std::byte pad[176];
    float fov;
    float fovViewModel;
    Vector origin;
    std::byte pad1[16];
    float farZ;
};

constexpr void fakeDuckFix(ViewSetup* setup) noexcept {
    if (localPlayer && localPlayer->isAlive() && config->antiAim.fakeDucking && localPlayer->flags() & 1)
        setup->origin.z = localPlayer->getAbsOrigin().z + interfaces->gameMovement->getPlayerViewOffset(false).z;
}

static void __stdcall overrideView(ViewSetup* setup) noexcept
{
    if (localPlayer && !localPlayer->isScoped())
        setup->fov += config->visuals.fov;
    if (localPlayer && localPlayer->isScoped())
        setup->fov += config->visuals.fovScoped;
    setup->farZ += config->visuals.farZ * 10;
    fakeDuckFix(setup);
    hooks->clientMode.callOriginal<void, 18>(setup);
}

struct RenderableInfo {
    Entity* renderable;
    std::byte pad[18];
    uint16_t flags;
    uint16_t flags2;
};

static int __stdcall listLeavesInBox(const Vector& mins, const Vector& maxs, unsigned short* list, int listMax) noexcept
{
    if (std::uintptr_t(_ReturnAddress()) == memory->listLeaves) {
        if (const auto info = *reinterpret_cast<RenderableInfo**>(std::uintptr_t(_AddressOfReturnAddress()) + 0x14); info && info->renderable) {
            if (const auto ent = VirtualMethod::call<Entity*, 7>(info->renderable - 4); ent && ent->isPlayer()) {
                if (config->misc.disableModelOcclusion) {
                    // FIXME: sometimes players are rendered above smoke, maybe sort render list?
                    info->flags &= ~0x100;
                    info->flags2 |= 0x40;

                    constexpr float maxCoord = 16384.0f;
                    constexpr float minCoord = -maxCoord;
                    constexpr Vector min{ minCoord, minCoord, minCoord };
                    constexpr Vector max{ maxCoord, maxCoord, maxCoord };
                    return hooks->bspQuery.callOriginal<int, 6>(std::cref(min), std::cref(max), list, listMax);
                }
            }
        }
    }
    return hooks->bspQuery.callOriginal<int, 6>(std::cref(mins), std::cref(maxs), list, listMax);
}

static int __fastcall dispatchSound(SoundInfo& soundInfo) noexcept
{
    if (const char* soundName = interfaces->soundEmitter->getSoundName(soundInfo.soundIndex)) {
        auto modulateVolume = [&soundInfo](int(*get)(int)) {
            if (auto entity{ interfaces->entityList->getEntity(soundInfo.entityIndex) }; entity && entity->isPlayer()) {
                if (localPlayer && soundInfo.entityIndex == localPlayer->index())
                    soundInfo.volume *= get(0) / 100.0f;
                else if (!entity->isOtherEnemy(localPlayer.get()))
                    soundInfo.volume *= get(1) / 100.0f;
                else
                    soundInfo.volume *= get(2) / 100.0f;
            }
        };

        modulateVolume([](int index) { return config->sound.players[index].masterVolume; });

        if (!strcmp(soundName, "Player.DamageHelmetFeedback"))
            modulateVolume([](int index) { return config->sound.players[index].headshotVolume; });
        else if (strstr(soundName, "Step"))
            modulateVolume([](int index) { return config->sound.players[index].footstepVolume; });
        else if (strstr(soundName, "Chicken"))
            soundInfo.volume *= config->sound.chickenVolume / 100.0f;
    }
    soundInfo.volume = std::clamp(soundInfo.volume, 0.0f, 1.0f);
    return hooks->originalDispatchSound(soundInfo);
}

static int __stdcall render2dEffectsPreHud(int param) noexcept
{
    Visuals::applyScreenEffects();
    Visuals::hitEffect();
    return hooks->viewRender.callOriginal<int, 39>(param);
}

static const DemoPlaybackParameters* __stdcall getDemoPlaybackParameters() noexcept
{
    const auto params = hooks->engine.callOriginal<const DemoPlaybackParameters*, 218>();

#ifdef _DEBUG
    // Check if we always get the same return address
    if (*static_cast<std::uint64_t*>(_ReturnAddress()) == 0x79801F74C985C88B) {
        static const auto returnAddress = std::uintptr_t(_ReturnAddress());
        assert(returnAddress == std::uintptr_t(_ReturnAddress()));
    }
#endif

    if (params && config->misc.revealSuspect && *static_cast<std::uint64_t*>(_ReturnAddress()) != 0x79801F74C985C88B) { // client.dll : 8B C8 85 C9 74 1F 80 79 10 00 , there game decides whether to show overwatch panel
        static DemoPlaybackParameters customParams;
        customParams = *params;
        customParams.anonymousPlayerIdentity = false;
        return &customParams;
    }

    return params;
}

static bool __stdcall isPlayingDemo() noexcept
{
#ifdef _DEBUG
    // Check if we always get the same return address
    if (*static_cast<std::uintptr_t*>(_ReturnAddress()) == 0x0975C084
        && **reinterpret_cast<std::uintptr_t**>(std::uintptr_t(_AddressOfReturnAddress()) + 4) == 0x0C75C084) {
        static const auto returnAddress = std::uintptr_t(_ReturnAddress());
        assert(returnAddress == std::uintptr_t(_ReturnAddress()));
    }
#endif

    if (config->misc.revealMoney
        && *static_cast<uintptr_t*>(_ReturnAddress()) == 0x0975C084 // client.dll : 84 C0 75 09 38 05
        && **reinterpret_cast<uintptr_t**>(uintptr_t(_AddressOfReturnAddress()) + 4) == 0x0C75C084) { // client.dll : 84 C0 75 0C 5B
        return true;
    }
    return hooks->engine.callOriginal<bool, 82>();
}

static void __stdcall updateColorCorrectionWeights() noexcept
{
    hooks->clientMode.callOriginal<void, 58>();

    if (const auto& cfg = config->visuals.colorCorrection; cfg.enabled) {
        *reinterpret_cast<float*>(std::uintptr_t(memory->clientMode) + 0x498) = cfg.blue;
        *reinterpret_cast<float*>(std::uintptr_t(memory->clientMode) + 0x4A0) = cfg.red;
        *reinterpret_cast<float*>(std::uintptr_t(memory->clientMode) + 0x4A8) = cfg.mono;
        *reinterpret_cast<float*>(std::uintptr_t(memory->clientMode) + 0x4B0) = cfg.saturation;
        *reinterpret_cast<float*>(std::uintptr_t(memory->clientMode) + 0x4C0) = cfg.ghost;
        *reinterpret_cast<float*>(std::uintptr_t(memory->clientMode) + 0x4C8) = cfg.green;
        *reinterpret_cast<float*>(std::uintptr_t(memory->clientMode) + 0x4D0) = cfg.yellow;
    }

    if (config->visuals.noScopeOverlay)
        *memory->vignette = 0.0f;
}

static float __stdcall getScreenAspectRatio(int width, int height) noexcept
{
    if (config->misc.aspectratio)
        return config->misc.aspectratio;
    return hooks->engine.callOriginal<float, 101>(width, height);
}

static void __stdcall renderSmokeOverlay(bool update) noexcept
{
    if (config->visuals.noSmoke || config->visuals.wireframeSmoke)
        *reinterpret_cast<float*>(std::uintptr_t(memory->viewRender) + 0x588) = 0.0f;
    else
        hooks->viewRender.callOriginal<void, 41>(update);
}

static bool __fastcall isConnected() noexcept
{
    if (_ReturnAddress() == memory->isLoadOutAvailable && config->misc.unlockInventory)
        return false;
    return hooks->engine.callOriginal<bool,27>();
}

static bool __fastcall isHltv() noexcept
{
    if (_ReturnAddress() == memory->SetupVelocityAddress || _ReturnAddress() == memory->AccumulateLayersAddress)
        return true;
    return hooks->engine.callOriginal<bool, 93>();
}

void WriteUsercmd(void* buf, UserCmd* in, UserCmd* out) 
{
    static DWORD WriteUsercmdF = (DWORD)memory->WriteUsercmd;

    __asm
    {
        mov ecx, buf
        mov edx, in
        push out
        call WriteUsercmdF
        add esp, 4
    }
}

static bool __fastcall WriteUsercmdDeltaToBuffer(void* ecx, void* edx, int slot, void* buffer, int from, int to, bool isnewcommand) noexcept
{
    auto original = hooks->client.getOriginal<bool, int, void*, int, int, bool>(24, slot, buffer, from, to, isnewcommand);

    if(_ReturnAddress() == memory->WriteUsercmdDeltaToBufferReturn || Tickbase::tick->tickshift <= 0 || !memory->clientState)
        return original(ecx, slot, buffer, from, to, isnewcommand);

    if (from != -1)
        return true;

    int* numBackupCommands = (int*)(reinterpret_cast <uintptr_t> (buffer) - 0x30);
    int* numNewCommands = (int*)(reinterpret_cast <uintptr_t> (buffer) - 0x2C);

    int32_t newcommands = *numNewCommands;

    int nextcommmand = memory->clientState->lastOutgoingCommand + memory->clientState->chokedCommands + 1;
    int totalcommands = std::min(Tickbase::tick->tickshift, Tickbase::tick->maxUsercmdProcessticks);
    Tickbase::tick->tickshift = 0;

    from = -1;
    *numNewCommands = totalcommands;
    *numBackupCommands = 0;

    for (to = nextcommmand - newcommands + 1; to <= nextcommmand; to++)
    {
        if (!(original(ecx, slot, buffer, from, to, true)))
            return false;

        from = to;
    }

    UserCmd* lastRealCmd = memory->input->GetUserCmd(slot, from);
    UserCmd fromcmd;

    if (lastRealCmd)
        fromcmd = *lastRealCmd;

    UserCmd tocmd = fromcmd;
    tocmd.tickCount += 200;
    tocmd.commandNumber++;

    for (int i = newcommands; i <= totalcommands; i++)
    {
        WriteUsercmd(buffer, &tocmd, &fromcmd);
        fromcmd = tocmd;
        tocmd.commandNumber++;
        tocmd.tickCount++;
    }

    return true;
}

static void __fastcall RunCommand(Prediction* ecx, void* edx, Entity* entity, UserCmd* cmd, MoveHelper* moveHelper)
{
    auto original = hooks->prediction.getOriginal<void, Entity*, UserCmd*, MoveHelper*>(19, entity, cmd, moveHelper);

    if (!entity || !localPlayer || entity != localPlayer.get())
        return original(ecx, entity, cmd, moveHelper);

    if (1 / memory->globalVars->intervalPerTick + Tickbase::tick->ticks + 8 <= cmd->tickCount)
    {
        cmd->hasbeenpredicted = true;
        return;
    }

    int tickbase = entity->tickBase();
    auto currentime = memory->globalVars->currenttime;

    if (cmd->commandNumber == Tickbase::tick->commandNumber)
        entity->tickBase() = Tickbase::tick->tickbase - Tickbase::tick->tickshift + 1;

    original(ecx, entity, cmd, moveHelper);

    if (cmd->commandNumber == Tickbase::tick->commandNumber)
    {
        entity->tickBase() = tickbase;
        memory->globalVars->currenttime = currentime;
    }
}

Hooks::Hooks(HMODULE module) noexcept
{
    _MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
    _MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_ON);

    this->module = module;

    // interfaces and memory shouldn't be initialized in wndProc because they show MessageBox on error which would cause deadlock
    interfaces = std::make_unique<const Interfaces>();
    memory = std::make_unique<const Memory>();

    window = FindWindowW(L"Valve001", nullptr);
    originalWndProc = WNDPROC(SetWindowLongPtrW(window, GWLP_WNDPROC, LONG_PTR(wndProc)));
}

void Hooks::install() noexcept
{
    SkinChanger::initializeKits();

    originalPresent = **reinterpret_cast<decltype(originalPresent)**>(memory->present);
    **reinterpret_cast<decltype(present)***>(memory->present) = present;
    originalReset = **reinterpret_cast<decltype(originalReset)**>(memory->reset);
    **reinterpret_cast<decltype(reset)***>(memory->reset) = reset;

    if constexpr (std::is_same_v<HookType, MinHook>)
        MH_Initialize();

    bspQuery.init(interfaces->engine->getBSPTreeQuery());
    client.init(interfaces->client);
    clientMode.init(memory->clientMode);
    engine.init(interfaces->engine);
    gameEventManager.init(interfaces->gameEventManager);
    modelRender.init(interfaces->modelRender);
    panel.init(interfaces->panel);
    prediction.init(interfaces->prediction);
    sound.init(interfaces->sound);
    surface.init(interfaces->surface);
    svCheats.init(interfaces->cvar->findVar("sv_cheats"));
    viewRender.init(memory->viewRender);

    bspQuery.hookAt(6, listLeavesInBox);
    client.hookAt(24, WriteUsercmdDeltaToBuffer);
    client.hookAt(37, frameStageNotify);
    clientMode.hookAt(17, shouldDrawFog);
    clientMode.hookAt(18, overrideView);
    clientMode.hookAt(24, createMove);
    clientMode.hookAt(27, shouldDrawViewModel);
    clientMode.hookAt(35, getViewModelFov);
    clientMode.hookAt(44, doPostScreenEffects);
    clientMode.hookAt(58, updateColorCorrectionWeights);
    engine.hookAt(27, isConnected);
    engine.hookAt(82, isPlayingDemo);
    engine.hookAt(93, isHltv);
    engine.hookAt(101, getScreenAspectRatio);
    engine.hookAt(218, getDemoPlaybackParameters);
    gameEventManager.hookAt(9, fireEventClientSide);
    modelRender.hookAt(21, drawModelExecute);
    panel.hookAt(41, paintTraverse);
    prediction.hookAt(19, RunCommand);
    sound.hookAt(5, emitSound);
    surface.hookAt(15, setDrawColor);
    surface.hookAt(67, lockCursor);
    svCheats.hookAt(13, svCheatsGetBool);
    viewRender.hookAt(39, render2dEffectsPreHud);
    viewRender.hookAt(41, renderSmokeOverlay);

    if (DWORD oldProtection; VirtualProtect(memory->dispatchSound, 4, PAGE_EXECUTE_READWRITE, &oldProtection)) {
        originalDispatchSound = decltype(originalDispatchSound)(uintptr_t(memory->dispatchSound + 1) + *memory->dispatchSound);
        *memory->dispatchSound = uintptr_t(dispatchSound) - uintptr_t(memory->dispatchSound + 1);
        VirtualProtect(memory->dispatchSound, 4, oldProtection, nullptr);
    }

    if constexpr (std::is_same_v<HookType, MinHook>)
        MH_EnableHook(MH_ALL_HOOKS);
}

extern "C" BOOL WINAPI _CRT_INIT(HMODULE module, DWORD reason, LPVOID reserved);

static DWORD WINAPI unload(HMODULE module) noexcept
{
    Sleep(100);

    interfaces->inputSystem->enableInput(true);
    eventListener->remove();

    ImGui_ImplDX9_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    _CRT_INIT(module, DLL_PROCESS_DETACH, nullptr);

    FreeLibraryAndExitThread(module, 0);
}

void Hooks::uninstall() noexcept
{
    if constexpr (std::is_same_v<HookType, MinHook>) {
        MH_DisableHook(MH_ALL_HOOKS);
        MH_Uninitialize();
    }

    bspQuery.restore();
    client.restore();
    clientMode.restore();
    engine.restore();
    gameEventManager.restore();
    modelRender.restore();
    panel.restore();
    prediction.restore();
    sound.restore();
    surface.restore();
    svCheats.restore();
    viewRender.restore();
    extraHook.restore();

    netvars->restore();

    Glow::clearCustomObjects();

    SetWindowLongPtrW(window, GWLP_WNDPROC, LONG_PTR(originalWndProc));
    **reinterpret_cast<void***>(memory->present) = originalPresent;
    **reinterpret_cast<void***>(memory->reset) = originalReset;

    if (DWORD oldProtection; VirtualProtect(memory->dispatchSound, 4, PAGE_EXECUTE_READWRITE, &oldProtection)) {
        *memory->dispatchSound = uintptr_t(originalDispatchSound) - uintptr_t(memory->dispatchSound + 1);
        VirtualProtect(memory->dispatchSound, 4, oldProtection, nullptr);
    }

    if (HANDLE thread = CreateThread(nullptr, 0, LPTHREAD_START_ROUTINE(unload), module, 0, nullptr))
        CloseHandle(thread);
}
