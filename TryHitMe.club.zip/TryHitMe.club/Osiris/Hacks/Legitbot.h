#pragma once

struct UserCmd;
struct Vector;

namespace Legitbot
{
    void run(UserCmd*) noexcept;
}